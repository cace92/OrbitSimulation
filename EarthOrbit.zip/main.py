import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button
import numpy as np
import pandas as pd
import csv
import os

# Function that read the excel setting file
def readsettings(filename):
    data = pd.read_excel(filename)
    return data

# Read orbit data from csv
def readCsv(filename):
    x = []
    y = []
    K = []
    U = []
    with open(filename) as csvfile:
        data = csv.DictReader(csvfile, delimiter=';')
        for row in data:
            x.append(float(row['x']))
            y.append(float(row['y']))
            K.append(float(row['K']))
            U.append(float(row['U']))
    return [x, y, K, U]

# Wrapper function
def computeOrbit_RK4_Cpp(x, y, vx, vy, mass1, mass2, dt, steps):
    command = './computeOrbit.exe '+str(steps)+' '+str(x)+' '+str(y)+' '+str(vx)+' '+str(vy)+' '+str(mass1)+' '+str(mass2)+' '+str(dt)
    os.system(command)
    return readCsv('orbitData.csv')

# Update function
def updatePlot(r0Xslider_, r0Yslider_, v0Xslider_, v0Yslider_, mass1, mass2):
    def update(val):
        rx2List, ry2List, Klist, Ulist = computeOrbit_RK4_Cpp(r0Xslider_.val, r0Yslider_.val, v0Xslider_.val,
                                                              v0Yslider_.val, mass1, mass2, dt, steps)
        sunPlot.set_xdata(0)
        sunPlot.set_xdata(0)
        orbitPlot.set_xdata(rx2List)
        orbitPlot.set_ydata(ry2List)
        Kplot.set_xdata(rx2List)
        Kplot.set_ydata(Klist)
        Uplot.set_xdata(rx2List)
        Uplot.set_ydata(Ulist)
        Eplot.set_xdata(rx2List)
        Eplot.set_ydata(np.array(Klist) + np.array(Ulist))
        ax.relim()
        ax.autoscale_view()
        axE.relim()
        axE.autoscale_view()
        fig.canvas.draw_idle()
    return update

# Sliders reset function
def resetSliders(event):
    r0Xslider.reset()
    r0Yslider.reset()
    v0Xslider.reset()
    v0Yslider.reset()

# MAIN


if __name__ == '__main__':
    G = 6.67408e-11

    # Bodies selection
    body1Name = 'sun'
    body2Name = 'mercury'

    # Reading settings
    settings = readsettings('settings.xls')
    mass1 = settings['mass'][settings['name'] == body1Name].values[0]
    mass2 = settings['mass'][settings['name'] == body2Name].values[0]
    radius1 = settings['radius'][settings['name'] == body1Name].values[0]
    radius2 = settings['radius'][settings['name'] == body2Name].values[0]
    colors1 = settings['colors'][settings['name'] == body1Name].values[0]
    colors2 = settings['colors'][settings['name'] == body2Name].values[0]

    # Parameters
    dt = settings['timestep_hours'][0] * 3600 / 240  # 1/4 of minute step in seconds
    steps = int(settings['steps_days'][0] * (24 / settings['timestep_hours'][0])) * 240  # Days to number of steps

    # Initial conditions
    vx1 = settings['vx0'][settings['name'] == body1Name].values[0]
    vy1 = settings['vy0'][settings['name'] == body1Name].values[0]
    rx2 = settings['x0'][settings['name'] == body2Name].values[0]
    ry2 = settings['y0'][settings['name'] == body2Name].values[0]
    vx2 = settings['vx0'][settings['name'] == body2Name].values[0]
    vy2 = settings['vy0'][settings['name'] == body2Name].values[0]

    fig, (ax, axE) = plt.subplots(1, 2, gridspec_kw={'width_ratios': [2, 1]})
    plt.subplots_adjust(left=0.25, bottom=0.25)
    ax.set_facecolor('black')
    fig.set_facecolor('skyblue')
    axR0x = plt.axes([0.1, 0.05 + 3 * 0.0225 + 0.02, 0.5, 0.0225])
    axR0y = plt.axes([0.1, 0.05 + 2 * 0.0225 + 0.02, 0.5, 0.0225])
    axV0x = plt.axes([0.1, 0.05 + 0.0225 + 0.02, 0.5, 0.0225])
    axV0y = plt.axes([0.1, 0.05, 0.5, 0.0225])
    axReset = plt.axes([0.8, 0.1, 0.1, 0.05])

    rx2Max = ry2Max = 2 * max(abs(rx2), abs(ry2))
    rx2Min = ry2Min = -2 * max(abs(rx2), abs(ry2))
    vx2Max = vy2Max = 2 * max(abs(vx2), abs(vy2))
    vx2Min = vy2Min = -2 * max(abs(vx2), abs(vy2))

    # Sliders
    r0Xslider = Slider(
        ax=axR0x,
        label='r0x',
        valmin=rx2Min,
        valmax=rx2Max,
        valinit=rx2,
        orientation='horizontal'
    )

    r0Yslider = Slider(
        ax=axR0y,
        label='r0y',
        valmin=ry2Min,
        valmax=ry2Max,
        valinit=ry2,
        orientation='horizontal'
    )

    v0Xslider = Slider(
        ax=axV0x,
        label='v0x',
        valmin=vx2Min,
        valmax=vx2Max,
        valinit=vx2,
        orientation='horizontal'
    )

    v0Yslider = Slider(
        ax=axV0y,
        label='v0y',
        valmin=vy2Min,
        valmax=vy2Max,
        valinit=vy2,
        orientation='horizontal'
    )

    resetButton = Button(ax=axReset, label='Reset')

    # Compute orbit
    rx2List, ry2List, Klist, Ulist = computeOrbit_RK4_Cpp(rx2, ry2, vx2, vy2, mass1, mass2, dt, steps)
    # Plot
    scaleFactor = 1e7
    orbitPlot = ax.plot(np.array(rx2List) / scaleFactor, np.array(ry2List) / scaleFactor,
                        color=colors2, linewidth=radius2 / scaleFactor, linestyle='-')[0]
    sunPlot = ax.plot(0, 0, marker='o', color=colors1, markersize=radius1 / scaleFactor)[0]
    ax.axis('equal')
    Kplot = axE.plot(np.array(rx2List) / scaleFactor, Klist, color='dodgerblue', label='K')[0]
    Uplot = axE.plot(np.array(rx2List) / scaleFactor, Ulist, color='crimson', label='U')[0]
    Eplot = axE.plot(np.array(rx2List) / scaleFactor, np.array(Klist) + np.array(Ulist), color='black', label='E')[0]
    axE.legend()
    ax.set_title('Orbit')
    ax.set_xlabel('[' + str(scaleFactor) + ' m]')
    ax.set_ylabel('[' + str(scaleFactor) + ' m]')
    axE.set_title('Energies')
    axE.set_xlabel('[' + str(scaleFactor) + ' m]')
    axE.set_ylabel('[J]')
    axE.grid()

    r0Xslider.on_changed(updatePlot(r0Xslider, r0Yslider, v0Xslider, v0Yslider, mass1, mass2))
    r0Yslider.on_changed(updatePlot(r0Xslider, r0Yslider, v0Xslider, v0Yslider, mass1, mass2))
    v0Xslider.on_changed(updatePlot(r0Xslider, r0Yslider, v0Xslider, v0Yslider, mass1, mass2))
    v0Yslider.on_changed(updatePlot(r0Xslider, r0Yslider, v0Xslider, v0Yslider, mass1, mass2))

    resetButton.on_clicked(resetSliders)

    figManager = plt.get_current_fig_manager()  # Full screen mode
    figManager.full_screen_toggle()
    plt.text(0.01, -1, 'ctrl+w to exit', fontsize=12)
    plt.subplots_adjust(left=0.076)
    plt.show()
