#include <iostream>
#include <fstream>
#include <string>
#include <cmath>

using namespace std;

// Square
inline double square(double a) {
      return a * a;
}

// Cube
inline double cube(double a) {
      return a * a * a;
}

// Kinetic energy
inline double kineticEnergy(double mass2, double x, double y, double vx, double vy) {
      return 0.5 * mass2 * square(x*vx + y*vy) / (square(x) + square(y));
}

// Potential energy
inline double effPotentialEnergy(double mass1, double mass2, double x, double y, double vx, double vy, const double G) {
      double r = sqrt(square(x) + square(y));
      return (0.5 * mass2 * square((x*vy - y*vx) / r)) - (G * mass1 * mass2 / r);
}

// Write orbit on csv file
void writeDataCsv(double* x, double* y, double* K, double* U, int stepsNum) {
      ofstream csvFile;
      csvFile.open("orbitData.csv");
      csvFile << "x" << ";" << "y" << ";" << "K" << ";" << "U" << "\n";
      for (int i=0; i<stepsNum; ++i) {
            csvFile << to_string(x[i]) << ";" << to_string(y[i]) << ";" << to_string(K[i]) << ";" << to_string(U[i]) << "\n";
      }
      csvFile.close();
}


// MAIN
int main(int argc, char* argv[]) {

      const double G = 6.67408e-11;

      // Get parameters from argv
      int stepsNum = strtol(argv[1], NULL, 10);
      double x0 = atof(argv[2]);
      double y0 = atof(argv[3]);
      double vx = atof(argv[4]);
      double vy = atof(argv[5]);
      double mass1 = atof(argv[6]);
      double mass2 = atof(argv[7]);
      double dt = atof(argv[8]);

      double x, y, r;
      double K1x, K1y, K1vx, K1vy;
      double K2x, K2y, K2vx, K2vy;
      double K3x, K3y, K3vx, K3vy;
      double K4x, K4y, K4vx, K4vy;

      double* xArr = (double*)malloc(stepsNum * sizeof(double));
      double* yArr = (double*)malloc(stepsNum * sizeof(double));
      double* Karr = (double*)malloc(stepsNum * sizeof(double));
      double* Uarr = (double*)malloc(stepsNum * sizeof(double));

      xArr[0] = x0;
      yArr[0] = y0;
      Karr[0] = kineticEnergy(mass2, xArr[0], yArr[0], vx, vy);
      Uarr[0] = effPotentialEnergy(mass1, mass2, xArr[0], yArr[0], vx, vy, G);

      // Loop to compute orbit points
      for (int i=1; i<stepsNum; ++i) {
            // Compute K1
            x = xArr[i-1];
            y = yArr[i-1];
            r = sqrt(square(x) + square(y));
            K1x = vx;
            K1y = vy;
            K1vx = -G * mass1 * x / cube(r);
            K1vy = -G * mass1 * y / cube(r);
            // Compute K2
            x = xArr[i-1] + 0.5 * K1x;
            y = yArr[i-1] + 0.5 * K1y;
            r = sqrt(square(x) + square(y));
            K2x = vx + 0.5 * K1vx;
            K2y = vy + 0.5 * K1vy;
            K2vx = -G * mass1 * x / cube(r);
            K2vy = -G * mass1 * y / cube(r);
            // Compute K3
            x = xArr[i-1] + 0.5 * K2x;
            y = yArr[i-1] + 0.5 * K2y;
            r = sqrt(square(x) + square(y));
            K3x = vx + 0.5 * K2vx;
            K3y = vy + 0.5 * K2vy;
            K3vx = -G * mass1 * x / cube(r);
            K3vy = -G * mass1 * y / cube(r);
            // Compute K4
            x = xArr[i-1] + K3x;
            y = yArr[i-1] + K3y;
            r = sqrt(square(x) + square(y));
            K4x = vx + K3vx;
            K4y = vy + K3vy;
            K4vx = -G * mass1 * x / cube(r);
            K4vy = -G * mass1 * y / cube(r);
            // Update coordinates and energies
            xArr[i] = xArr[i-1] + (dt / 6) * (K1x + 2*K2x + 2*K3x + K4x);
            yArr[i] = yArr[i-1] + (dt / 6) * (K1y + 2*K2y + 2*K3y + K4y);
            vx = vx + (dt / 6) * (K1vx + 2*K2vx + 2*K3vx + K4vx);
            vy = vy + (dt / 6) * (K1vy + 2*K2vy + 2*K3vy + K4vy);
            Karr[i] = kineticEnergy(mass2, xArr[i], yArr[i], vx, vy);
            Uarr[i] = effPotentialEnergy(mass1, mass2, xArr[i], yArr[i], vx, vy, G);
      }

      // Write data on csv file
      writeDataCsv(xArr, yArr, Karr, Uarr, stepsNum);

      return 0;
}