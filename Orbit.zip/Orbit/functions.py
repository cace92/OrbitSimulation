import pandas as pd

# Function that read the excel setting file
def readsettings(filename):
	data = pd.read_excel(filename)
	return(data)

# Function to compute the 2d euclidean distance
def dist2d(rx1, rx2, ry1, ry2):
	return(((rx1-rx2)**2 + (ry1-ry2)**2)**(1/2))

# Function that update acceleration of body i
def update_a(i, N, rx, ry, mass, G):
	ax = 0
	ay = 0
	others = set(range(N))
	others.remove(i)
	for j in others:
		dist = dist2d(rx[i], rx[j], ry[i], ry[j])
		ax = ax + mass[j]*(rx[j]-rx[i])/dist**3
		ay = ay + mass[j]*(ry[j]-ry[i])/dist**3
	ax = ax*G
	ay = ay*G
	return([ax, ay])