import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.cm as cm
from matplotlib.offsetbox import AnchoredText
import numpy as np
from functions import readsettings, dist2d, update_a

# Reading settings
settings = readsettings('settings.xls')
id = list(settings['ID'])
names = list(settings['name'])
mass = list(settings['mass'])
radius = list(settings['radius'])
colors = list(settings['colors'])
N = len(id)

# Parameters
G = 6.67408e-11
dt = settings['timestep_hours'][0]*3600 # Hours to seconds
steps = int(settings['steps_days'][0]*(24/settings['timestep_hours'][0])) # Days to steps

# Initial conditions
rx = list(settings['x0'])
ry = list(settings['y0'])
vx = list(settings['vx0'])
vy = list(settings['vy0'])
	
# Initial gravitational acceleration
ax = []
ay = []
for i in range(N):
	a = update_a(i, N, rx, ry, mass, G)
	ax.append(a[0])
	ay.append(a[1])

# Orbit plot-Leapfrog integration
fig = plt.figure()
fig.set_facecolor('skyblue')
axes = fig.add_subplot(1, 1, 1)
axes.set_facecolor('black')
for i in range(N):
	plt.scatter(rx[i], ry[i], facecolor = colors[i], s = (radius[i]/max(radius)*400), label = names[i])
print('Computing and plotting the orbits...')
print('Ctrl+w to exit')
for s in range(steps):
	for i in range(N):
		vx1_2 = vx[i] + ax[i]*dt/2 # Half steps
		vy1_2 = vy[i] + ay[i]*dt/2
		rx[i] = rx[i] + vx1_2*dt
		ry[i] = ry[i] + vy1_2*dt
		a = update_a(i, N, rx, ry, mass, G)
		ax[i] = a[0]
		ay[i] = a[1]
		vx[i] = vx1_2 + ax[i]*dt/2
		vy[i] = vy1_2 + ay[i]*dt/2
		# Plot
		plt.scatter(rx[i], ry[i], facecolor = colors[i], s = (radius[i]/max(radius)*400))
figManager = plt.get_current_fig_manager()  # Fullscreen mode
figManager.full_screen_toggle()
axes.legend(loc='lower right')
exit = AnchoredText('Type ctrl+w to exit', prop = dict(size = 9), frameon = True, loc = 2) # Exit instruction
exit.patch.set_boxstyle('round,pad=0.,rounding_size=0.2')
axes.add_artist(exit)
axes.set_aspect('equal', 'box')
plt.show()
		
		
		